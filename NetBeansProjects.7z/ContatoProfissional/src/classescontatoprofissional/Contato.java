package classescontatoprofissional;

public class Contato {
    private String telefone;
    private String celular;
    private String email;
    private String telcontato;

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelcontato() {
        return telcontato;
    }

    public void setTelcontato(String telcontato) {
        this.telcontato = telcontato;
    }
    
    
}
