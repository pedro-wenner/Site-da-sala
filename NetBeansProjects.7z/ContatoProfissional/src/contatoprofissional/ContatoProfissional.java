package contatoprofissional;

import telacontatoprofissional.JFprincipal;

public class ContatoProfissional {

    public static void main(String[] args) {
        JFprincipal jfprincipal = new JFprincipal();
        jfprincipal.show();
    }
    
}
