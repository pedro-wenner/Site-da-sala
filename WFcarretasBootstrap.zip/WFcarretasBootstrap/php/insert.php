<?php

require 'Conexao.php';

if (!empty($_POST)) {
    // keep track validation errors
    $nomeError = null;
    $telError = null;
    $emailError = null;
    $opcaoError = null;
    $textoError = null;

    // keep track post values
    $nome = $_POST['nome'];
    $tel = $_POST['telefone'];
    $email = $_POST['email'];
    $opcao = $_POST['opcao'];
    $texto = $_POST['texto'];
    
        $pdo = Conexao::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "INSERT INTO orcamento (nome,telefone,email,opcao,descricao) values(?, ?, ?, ?, ?)";
        $q = $pdo->prepare($sql);
        $q->execute(array($nome, $tel, $email, $opcao, $texto));
        Conexao::disconnect();
        header("Location: ../index.php?s=1");
    }
