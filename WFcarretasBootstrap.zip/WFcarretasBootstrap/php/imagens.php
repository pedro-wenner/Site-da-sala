<?php

for ($i = 0; $i < 10; $i++) {
    ?>

    <section class = "no-padding" id ="portfolio">
        <div class = "container-fluid">
            <div class = "row no-gutter popup-gallery">

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/2014-01-10 16.40.09.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/2014-01-10 16.40.09.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Reboque
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/2014-01-20 10.45.09.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/2014-01-20 10.45.09.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Reboque
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/20150605_101237.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/20150605_101237.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Reboque
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/20150707_173547.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/20150707_173547.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Reboque
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/20150707_173547.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/20150707_173547.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Reboque
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/IMG-20151129-WA0016.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/IMG-20151129-WA0016.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Category
                                </div>
                                <div class="project-name">
                                    Reboque
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/2014-01-20 10.45.09.jpg" class="portfolio-box portifolio-box">
                        <img src="img/PortifolioCarretinha/2014-01-20 10.45.09.jpg" class="img-responsive" alt=""/>
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Basculante
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/2014-01-10 16.40.09.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/2014-01-10 16.40.09.jpg" class="img-responsive" alt=""/>
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Fazendinha
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <a href="img/PortifolioCarretinha/2014-01-10 16.40.09.jpg" class="portfolio-box">
                        <img src="img/PortifolioCarretinha/2014-01-10 16.40.09.jpg" class="img-responsive" alt=""/>
                        <div class="portfolio-box-caption portifolio-box">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Categoria
                                </div>
                                <div class="project-name">
                                    Fazendinha
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <?php

}
