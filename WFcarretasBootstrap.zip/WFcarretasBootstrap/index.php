<!DOCTYPE html>
<html lang = "pt-br">

    <head>

        <meta charset = "utf-8">
        <meta http-equiv = "X-UA-Compatible" content = "IE=edge">
        <meta name = "viewport" content = "width=device-width, initial-scale=1">
        <meta name = "description" content = " Reboques, WF carretas, carretinhas ">
        <meta name = "author" content = " Pedro Wenner ">

        <!--Icone da favicon -->
        <link rel = "icon" href = "img/reboqueicon.png">

        <title>WF Carretas &AMP;
            Engates</title>

        <!--Bootstrap Core CSS -->
        <link href = "vendor/bootstrap/css/bootstrap.min.css" rel = "stylesheet">

        <!--Custom Fonts -->
        <link href = "vendor/font-awesome/css/font-awesome.min.css" rel = "stylesheet" type = "text/css">
        <link href = 'https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel = 'stylesheet' type = 'text/css'>
        <link href = 'https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel = 'stylesheet' type = 'text/css'>

        <!--Plugin CSS -->
        <link href = "vendor/magnific-popup/magnific-popup.css" rel = "stylesheet">

        <!--Theme CSS -->
        <link href = "css/creative.min.css" rel = "stylesheet">

        <!--Pedro CSS -->
        <link href = "css/estilo.css" rel = "stylesheet" type = "text/css"/>


        <!--HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!--WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        
    </head>

    <body id="page-top">

        <nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-principal">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span> <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand page-scroll titulo" href="#page-top">WF Reboques &AMP; Engates</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a class="page-scroll" href="#about"> Quem Somos </a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#services"> Serviços </a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#portfolio"> Portifolio </a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#localização"> Localização </a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#orcamento"> Orçamento </a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#contact"> Contato </a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>

        <header>
            <div class="header-content">
                <div class="header-content-inner">
                    <h1 id="homeHeading"> O melhor em reboques e engates. Feito para Você! </h1>
                    <hr class="faixa">
                    <p> WF Carretas pode ajudar você quando o assunto é <b>Reboques</b> e <b>Engates</b>. Com o melhor serviço e qualidade no mercado. </p>
                    <a href="#about" class="btn btn-primary btn-xl page-scroll btn-primeiro"> Conheça mais nossa história </a>
                </div>
            </div>
        </header>
        <?php
        if (isset($_GET['s'])) {
            ?>  
            <span class="mensagem">Mensagem enviada com sucesso!</span>
            <a class="mensagem x" href="index.php">X</a>
            <?php
        }
        ?>
        <section class="bg-primary sobre" id="about">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 text-center">
                        <h2 class="section-heading"> Nós temos o que você precisa! </h2>
                        <hr class="light">
                        <p class="text-faded"> A WF Reboques & Engates Ltda, foi fundada em 12 de março de 2014 com o objetivo de fornecer um produto com qualidade e com fácil acessibilidade para você. Nós temos os melhores reboques e semi-reboques, todos testados e aprovados pelo INMETRO e com RENAVAM fornecido pelo DENATRAN. </p>
                        <a href="#services" class="page-scroll btn btn-default btn-xl sr-button"> Vamos lá! </a>
                    </div>
                </div>
            </div>
        </section>

        <section id="services">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="section-heading"> Ao Seu Serviço </h2>
                        <hr class="primary faixa">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="service-box">
                            <img class="fa fa-4x text-primary sr-icons" src="img/reboqueicon.jpg" alt="Reboque">
                            <h3> Reboques </h3>
                            <p class="text-muted"> Os melhores reboques da região. Todos aprovados e testados pelo INMETRO. </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="service-box">
                            <img class="fa fa-4x text-primary sr-icons" src="img/traillericon.jpg" alt="Semi-Reboque">
                            <h3> Costumização </h3>
                            <p class="text-muted"> Você pode pedir o seu Reboque da maneira que quiser. Fazemos ele de todos os tamanhos e estilos. </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="service-box">
                            <img class="fa fa-4x text-primary sr-icons" src="img/semireboqueicon.jpg" alt="Engate">
                            <h3> Engates </h3>
                            <p class="text-muted"> Instalamos engates aprovados pelo INMETRO. Você poderá sair com o seu reboque engatado na hora. </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="service-box">
                            <img class="fa fa-4x text-primary sr-icons" src="img/trabalhoicon.jpg"> 
                            <h3> Feito para Você! </h3>
                            <p class="text-muted"> Com excelente atendimento e destinado totalmente para você. </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="portifolio">
            <?php
            include 'php/imagens.php';
            ?>
        </div>

        <section id="localização" class="cont-esq">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 text-center">
                        <h2 class="section-heading"> Localização  </h2>
                        <hr class="primary faixa">
                    </div>
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d240.1434001495585!2d-56.07771050344592!3d-15.62930359120074!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1cfcbf540e4c27d2!2sFama+Ferragens+e+Acess%C3%B3rios+Serralheria!5e0!3m2!1spt-BR!2sbr!4v1477485922211"></iframe>                    
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="orcamento" class="cont-direita">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 text-center">
                        <h2 class="section-heading"> Orçamento  </h2>
                        <hr class="primary faixa">
                        <p> Mande-nos uma mensagem e faremos o orçamento do seu reboque. </p>
                    </div>
                    <div class="col-lg-8 col-lg-offset-2">
                        <form action="php/insert.php" method="post">
                            <div class="form-group">
                                <label for="exampleInputNome"> Nome </label>
                                <input name="nome" type="text" class="form-control formulario" id="exampleInputNome" placeholder="Informe seu nome" pattern="[a-zA-Z\s]+$" title="Nome Informado Incorreto" required="">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputNome"> Telefone </label>
                                <input name="telefone" type="text" class="form-control formulario phone" id="exampleInputTel" placeholder="Informe seu Telefone" pattern="\(\d{(2)}\)\d{4}-\d{4}" title="Telefone Informado Incorreto!" required="" data-mask="(00) 00000-0000" data-mask-selectonfocus="true">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputNome"> E-mail </label>
                                <input name="email" type="email" class="form-control" id="exampleInputEmail" placeholder="Informe seu email" title="E-mail Informado Incorreto!" required="">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputSelecao"> Selecione </label>
                                <select name="opcao" class="form-control formulario">
                                    <option>Orçamento</option>
                                    <option>Reclamações</option>
                                    <option>Agradecimentos</option>
                                    <option>Dúvidas</option>                                    
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputTextarea"> Informe as especificações do reboque </label>
                                <textarea name="texto" class="form-control formulario" rows="3" placeholder="Digite seu texto" required=""></textarea>
                            </div>
                            <button type="submit" class="btn btn-success"> Enviar </button>
                            <button type="reset" class="btn btn-danger"> Limpar </button>
                        </form>
                        <div class="validacao"></div>
                    </div>
                </div>
            </div>
        </section>

        <section id="contact">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 text-center">
                        <h2 class="section-heading"> Contato  </h2>
                        <hr class="primary faixa">
                        <p> Pronto para conhecer a WF Carretas? ligue ou mande um e-mail. </p>
                    </div>
                    <div class="col-lg-4 col-lg-offset-2 text-center">
                        <i class="fa fa-phone fa-3x sr-contact"></i>
                        <p> 65 3365-1454 </p>
                        <p> 65 99904-3504 </p>
                        <p> 65 99977-3531 </p>
                    </div>
                    <div class="col-lg-4 text-center">
                        <i class="fa fa-envelope-o fa-3x sr-contact"></i>
                        <p><a href="mailto:your-email@your-domain.com"> wfcarretas@gmail.com </a></p>
                    </div>
                </div>
            </div>
        </section>

        <!-- jQuery -->
        <script src="vendor/jquery/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
        <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
        <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

        <!-- Theme JavaScript -->
        <script src="js/creative.min.js"></script>
        
        <!-- Pedro Js -->
        <script src="js/estilo.js" type="text/javascript"></script>

        <!-- Mask Js -->
        <script src="js/jquery.mask.min.js" type="text/javascript"></script>
        
    </body>
</html>
